<?php
/*======
*
* Kirki Settings
*
======*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Kirki' ) ) {
	return;
}

Kirki::add_config(
	'medicase_customizer', array(
		'capability'  => 'edit_theme_options',
		'option_type' => 'theme_mod',
	)
);

/*======
*
* Sections
*
======*/
$sections = array(
	'shop_settings' => array (
		esc_attr__( 'Shop Settings', 'medicase-core' ),
		esc_attr__( 'You can customize the shop settings.', 'medicase-core' ),
	),
	
	'blog_settings' => array (
		esc_attr__( 'Blog Settings', 'medicase-core' ),
		esc_attr__( 'You can customize the blog settings.', 'medicase-core' ),
	),

	'header_settings' => array (
		esc_attr__( 'Header Settings', 'medicase-core' ),
		esc_attr__( 'You can customize the header settings.', 'medicase-core' ),
	),

	'main_color' => array (
		esc_attr__( 'Main Color', 'medicase-core' ),
		esc_attr__( 'You can customize the main color.', 'medicase-core' ),
	),
	
	'elementor_templates' => array (
		esc_attr__( 'Elementor Templates', 'medicase-core' ),
		esc_attr__( 'You can customize the elementor templates.', 'medicase-core' ),
	),
	
	'map_settings' => array (
		esc_attr__( 'Map Settings', 'medicase-core' ),
		esc_attr__( 'You can customize the map settings.', 'medicase-core' ),
	),

	'footer_settings' => array (
		esc_attr__( 'Footer Settings', 'medicase-core' ),
		esc_attr__( 'You can customize the footer settings.', 'medicase-core' ),
	),
	
	'medicase_widgets' => array (
		esc_attr__( 'medicase Widgets', 'medicase-core' ),
		esc_attr__( 'You can customize the medicase widgets.', 'medicase-core' ),
	),

);

foreach ( $sections as $section_id => $section ) {
	$section_args = array(
		'title' => $section[0],
		'description' => $section[1],
	);

	if ( isset( $section[2] ) ) {
		$section_args['type'] = $section[2];
	}

	if( $section_id == "colors" ) {
		Kirki::add_section( str_replace( '-', '_', $section_id ), $section_args );
	} else {
		Kirki::add_section( 'medicase_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
	}
}


/*======
*
* Fields
*
======*/
function medicase_customizer_add_field ( $args ) {
	Kirki::add_field(
		'medicase_customizer',
		$args
	);
}

	/*====== Shop ======*/
		/*====== Shop Panels ======*/
		Kirki::add_panel (
			'medicase_shop_panel',
			array(
				'title' => esc_html__( 'Shop Settings', 'medicase-core' ),
				'description' => esc_html__( 'You can customize the shop from this panel.', 'medicase-core' ),
			)
		);

		$sections = array (
			'shop_general' => array(
				esc_attr__( 'General', 'medicase-core' ),
				esc_attr__( 'You can customize shop settings.', 'medicase-core' )
			),
			
			'single_product' => array(
				esc_attr__( 'Single Product', 'medicase-core' ),
				esc_attr__( 'You can customize shop single settings.', 'medicase-core' )
			),
			
			'shop_breadcrumb' => array(
				esc_attr__( 'Breadcrumb', 'medicase-core' ),
				esc_attr__( 'You can customize shop settings.', 'medicase-core' )
			),
			
			'mobile_bottom_menu_style' => array(
				esc_attr__( 'Mobile Bottom Menu Style ', 'medicase-core' ),
				esc_attr__( 'You can customize the mobile menu.', 'medicase-core' )
			),
			
			'testimonial_slider_widget' => array(
				esc_attr__( 'Testimonial Slider Widget', 'medicase-core' ),
				esc_attr__( 'When you add the Testimonial Slider Widget in Dashboard > Appearance > Widgets, you can customize the settings from there.', 'medicase-core' )
			),

		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'medicase_shop_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'medicase_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Shop Layouts ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'medicase_shop_layout',
				'label' => esc_attr__( 'Layout', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose a layout for the shop.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => 'left-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'medicase-core' ),
					'full-width' => esc_attr__( 'Full Width', 'medicase-core' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'medicase-core' ),
				),
			)
		);
		
		/*====== Pagination Type ======*/
		medicase_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'medicase_paginate_type',
			'label'       => esc_html__( 'Pagination Type', 'medicase-core' ),
			'section'     => 'medicase_shop_general_section',
			'default'     => 'default',
			'priority'    => 10,
			'choices'     => array(
				'default' => esc_attr__( 'Default', 'medicase-core' ),
				'loadmore' => esc_attr__( 'Load More', 'medicase-core' ),
				'infinite' => esc_attr__( 'Infinite', 'medicase-core' ),
			),
			) 
		);
		
		/*====== Shop Mobile Column======*/
		medicase_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'medicase_shop_mobile_column',
				'label' => esc_attr__( 'Shop Mobile Column', 'medicase-core' ),
				'description' => esc_attr__( 'Set column for the mobile column.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '1column',
				'choices' => array(
					'1column' => esc_attr__( '1 column', 'medicase-core' ),
					'2columns' => esc_attr__( '2 columns', 'medicase-core' ),
					'3columns' => esc_attr__( '3 columns', 'medicase-core' ),
				),
			)
		);

		/*====== Ajax on Shop Page ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_ajax_on_shop',
				'label' => esc_attr__( 'Ajax on Shop Page', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable Ajax for the shop page.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Grid-List Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_grid_list_view',
				'label' => esc_attr__( 'Grid List View', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable grid list view on shop page.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Quick View Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_quick_view_button',
				'label' => esc_attr__( 'Quick View Button', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose status of the quick view button.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Wishlist Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_wishlist_button',
				'label' => esc_attr__( 'Custom Wishlist Button', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose status of the wishlist button.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Recently Viewed Products ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_recently_viewed_products',
				'label' => esc_attr__( 'Recently Viewed Products', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable Recently Viewed Products.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Product Stock Quantity ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_stock_quantity',
				'label' => esc_attr__( 'Stock Quantity', 'medicase-core' ),
				'description' => esc_attr__( 'Show stock quantity on the label.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Product Min/Max Quantity ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_min_max_quantity',
				'label' => esc_attr__( 'Min/Max Quantity', 'medicase-core' ),
				'description' => esc_attr__( 'Enable the additional quantity setting fields in product detail page.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Ajax Notice Shop ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_notice_ajax_addtocart',
				'label' => esc_attr__( 'Ajax Notice', 'medicase' ),
				'description' => esc_attr__( 'You can choose status of the ajax notice feature.', 'medicase' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Category Description ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_category_description_after_content',
				'label' => esc_attr__( 'Category Desc After Content', 'medicase-core' ),
				'description' => esc_attr__( 'Add the category description after the products.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Catalog Mode - Disable Add to Cart ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_catalog_mode',
				'label' => esc_attr__( 'Catalog Mode', 'medicase-core' ),
				'description' => esc_attr__( 'Disable Add to Cart button on the shop page.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Min Order Amount ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_min_order_amount_toggle',
				'label' => esc_attr__( 'Min Order Amount', 'medicase-core' ),
				'description' => esc_attr__( 'Enable Min Order Amount.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Min Order Amount Value ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_min_order_amount_value',
				'label' => esc_attr__( 'Min Order Value', 'medicase-core' ),
				'description' => esc_attr__( 'Set amount to specify a minimum order value.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'medicase_min_order_amount_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_mobile_bottom_menu',
				'label' => esc_attr__( 'Mobile Bottom Menu', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable the bottom menu on mobile.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Mobile Bottom Menu Edit Toggle======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_mobile_bottom_menu_edit_toggle',
				'label' => esc_attr__( 'Mobile Bottom Menu Edit', 'medicase-core' ),
				'description' => esc_attr__( 'Edit the mobile bottom menu.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'medicase_mobile_bottom_menu',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				
			)
			
		);
		
		/*====== Mobile Menu Repeater ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'medicase_mobile_bottom_menu_edit',
				'label' => esc_attr__( '', 'medicase-core' ),
				'description' => esc_attr__( '', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'required' => array(
					array(
					  'setting'  => 'medicase_mobile_bottom_menu_edit_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				'fields' => array(
					'mobile_menu_type' => array(
						'type' => 'select',
						'label' => esc_attr__( 'Select Type', 'medicase-core' ),
						'description' => esc_attr__( 'You can select a type', 'medicase-core' ),
						'default' => 'default',
						'choices' => array(
							'default' 	=> esc_attr__( 'Default', 'medicase-core' ),
							'Home'		=> esc_attr__( 'Home', 'medicase-core' ),
							'Shop' 		=> esc_attr__( 'Shop', 'medicase-core' ),
							'Filter' 	=> esc_attr__( 'Filter', 'medicase-core' ),
							'Cart' 		=> esc_attr__( 'Cart', 'medicase-core' ),
							'Myaccount' => esc_attr__( 'Myaccount', 'medicase-core' ),
						),
					),
				
					'mobile_menu_icon' => array(
						'type' 			=> 'text',
						'label' 		=> esc_attr__( 'Icon', 'medicase-core' ),
						'description' 	=> esc_attr__( 'You can set an icon. for example; "home"', 'medicase-core' ),
					),

					'mobile_menu_url' => array(
						'type'			=> 'text',
						'label' 		=> esc_attr__( 'URL', 'medicase-core' ),
						'description' 	=> esc_attr__( 'You can set url for the item.', 'medicase-core' ),
					),
				),
				
			)
		);

		/*====== Product Image Size ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'dimensions',
				'settings' => 'medicase_product_image_size',
				'label' => esc_attr__( 'Product Image Size', 'medicase-core' ),
				'description' => esc_attr__( 'You can set size of the product image for the shop page.', 'medicase-core' ),
				'section' => 'medicase_shop_general_section',
				'default' => array(
					'width' => '',
					'height' => '',
				),
			)
		);
		
		/*====== Shop Single Image Column ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'medicase_shop_single_image_column',
				'label'       => esc_html__( 'Image Column', 'medicase-core' ),
				'section'     => 'medicase_single_product_section',
				'default'     => 6,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 3,
					'max'  => 12,
					'step' => 1,
				],
			)
		);
		
		/*====== Re-Order Product Detail ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'sortable',
				'settings' => 'medicase_shop_single_reorder',
				'label' => esc_attr__( 'Re-order Product Summary', 'medicase' ),
				'description' => esc_attr__( 'Please save the changes and refresh the page once. Live preview is not available for the option.', 'medicase' ),
				'section' => 'medicase_single_product_section',
				'default'     => [
					'woocommerce_template_single_title',
					'woocommerce_template_single_rating',
					'woocommerce_template_single_price',
					'woocommerce_template_single_excerpt',
					'woocommerce_template_single_add_to_cart',
					'woocommerce_template_single_meta',
					'medicase_social_share',
				],
				'choices'     => [
					'woocommerce_template_single_title' => esc_html__( 'Title', 'medicase' ),
					'woocommerce_template_single_rating' => esc_html__( 'Rating', 'medicase' ),
					'woocommerce_template_single_price' => esc_html__( 'Price', 'medicase' ),
					'woocommerce_template_single_excerpt' => esc_html__( 'Excerpt', 'medicase' ),
					'woocommerce_template_single_add_to_cart' => esc_html__( 'Add to Cart', 'medicase' ),
					'woocommerce_template_single_meta' => esc_html__( 'Meta', 'medicase' ),
					'medicase_social_share' => esc_html__( 'Share', 'medicase' ),
					'medicase_product_stock_progress_bar' => esc_html__( 'Progress Bar', 'medicase-core' ),
					'medicase_product_time_countdown' => esc_html__( 'Time Countdown', 'medicase-core' ),
				],
			)
		);
		
		
		/*====== Shop Products Navigation  ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_products_navigation',
				'label' => esc_attr__( 'Products Navigation', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Ajax Add To Cart ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_ajax_addtocart',
				'label' => esc_attr__( 'Ajax Add to Cart', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable ajax add to cart button.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Product360 View ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_product360',
				'label' => esc_attr__( 'Product360 View', 'medicase' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Image Zoom  ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_single_image_zoom',
				'label' => esc_attr__( 'Image Zoom', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose status of the zoom feature.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*======  Sticky Single Cart ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_single_sticky_cart',
				'label' => esc_attr__( 'Sticky Add to Cart', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable sticky cart button.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Mobile Sticky Single Cart ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_mobile_single_sticky_cart',
				'label' => esc_attr__( 'Mobile Sticky Add to Cart', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable sticky cart button on mobile.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Move Review Tab ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_review_tab_move',
				'label' => esc_attr__( 'Move Review Tab', 'medicase' ),
				'description' => esc_attr__( 'Move the review tab out of tabs', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Buy Now Single ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_buy_now',
				'label' => esc_attr__( 'Buy Now Button', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable Buy Now button.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Order on WhatsApp ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_orderonwhatsapp',
				'label' => esc_attr__( 'Order on WhatsApp', 'medicase' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Order on WhatsApp Number======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_shop_single_whatsapp_number',
				'label' => esc_attr__( 'WhatsApp Number', 'medicase' ),
				'description' => esc_attr__( 'You can add a phone number for order on WhatsApp.', 'medicase' ),
				'section' => 'medicase_single_product_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_single_orderonwhatsapp',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Single Social Share ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_social_share',
				'label' => esc_attr__( 'Social Share', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable social share buttons.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Social Share ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'multicheck',
				'settings'    => 'medicase_shop_single_share',
				'section'     => 'medicase_single_product_section',
				'default'     => array('facebook','twitter', 'pinterest', 'linkedin'  ),
				'priority'    => 10,
				'choices'     => [
					'facebook'  => esc_html__( 'Facebook', 	'medicase-core' ),
					'twitter' 	=> esc_html__( 'Twitter', 	'medicase-core' ),
					'pinterest' => esc_html__( 'Pinterest', 'medicase-core' ),
					'linkedin'  => esc_html__( 'Linkedin', 	'medicase-core' ),
				],
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_social_share',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Shop Single Banner Toggle======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_single_banner_toggle',
				'label' => esc_attr__( 'Banner', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable the banner.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Banner======*/
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_shop_single_banner_img',
				'label' => esc_attr__( 'Banner Image', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload an image for the banner section.', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_single_banner_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Shop Single Banner URL======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_shop_single_banner_url',
				'label' => esc_attr__( 'Banner URL', 'medicase-core' ),
				'description' => esc_attr__( 'You can set an url for the banner', 'medicase-core' ),
				'section' => 'medicase_single_product_section',
				'default' => '#',
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_single_banner_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Breadcrumb Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_shop_breadcrumb',
				'label' => esc_attr__( 'Breadcrumb', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable breadcrumb on shop pages.', 'medicase-core' ),
				'section' => 'medicase_shop_breadcrumb_section',
				'default' => '0',
			)
		);
		
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_shop_breadcrumb_bg',
				'label' => esc_attr__( 'Breadcrumb Background', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload a background image for the breadcrumb.', 'medicase-core' ),
				'section' => 'medicase_shop_breadcrumb_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_breadcrumb',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Breadcrumb Text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_breadcrumb_title',
				'label' => esc_attr__( 'Breadcrumb Title', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a title for the breadcrumb..', 'medicase-core' ),
				'section' => 'medicase_shop_breadcrumb_section',
				'default' => 'Products',
				'required' => array(
					array(
					  'setting'  => 'medicase_shop_breadcrumb',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*======  Mobile Menu Background Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'medicase_mobile_menu_bg_color',
				'label' => esc_attr__( 'Mobile Menu Background Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a background color.', 'medicase-core' ),
				'section' => 'medicase_mobile_bottom_menu_style_section',
			)
		);
		
		/*======  Mobile Menu Border Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#edf1f4',
				'settings' => 'medicase_mobile_menu_border_color',
				'label' => esc_attr__( 'Mobile Menu Border Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a border color.', 'medicase-core' ),
				'section' => 'medicase_mobile_bottom_menu_style_section',
			)
		);
		
		/*======  Mobile Menu Icon Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_mobile_menu_icon_color',
				'label' => esc_attr__( 'Mobile Menu Icon Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color.', 'medicase-core' ),
				'section' => 'medicase_mobile_bottom_menu_style_section',
			)
		);
		
		/*======  Mobile Menu Icon Hover Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_mobile_menu_icon_hvrcolor',
				'label' => esc_attr__( 'Mobile Menu Icon Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color.', 'medicase-core' ),
				'section' => 'medicase_mobile_bottom_menu_style_section',
			)
		);

	/*====== Blog Settings ======*/
		/*====== Layouts ======*/
		
		medicase_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'medicase_blog_layout',
				'label' => esc_attr__( 'Layout', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose a layout.', 'medicase-core' ),
				'section' => 'medicase_blog_settings_section',
				'default' => 'right-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'medicase-core' ),
					'full-width' => esc_attr__( 'Full Width', 'medicase-core' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'medicase-core' ),
				),
			)
		);
		
		/*====== Blog Breadcrumb Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_blog_breadcrumb',
				'label' => esc_attr__( 'Breadcrumb', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable breadcrumb on blog pages.', 'medicase-core' ),
				'section' => 'medicase_blog_settings_section',
				'default' => '1',
			)
		);
		
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_blog_breadcrumb_bg',
				'label' => esc_attr__( 'Breadcrumb Background', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload a background image for the breadcrumb.', 'medicase-core' ),
				'section' => 'medicase_blog_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'medicase_blog_breadcrumb',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Blog Breadcrumb Text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_blog_breadcrumb_title',
				'label' => esc_attr__( 'Breadcrumb Title', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a title for the breadcrumb..', 'medicase-core' ),
				'section' => 'medicase_blog_settings_section',
				'default' => 'Blog Posts',
				'required' => array(
					array(
					  'setting'  => 'medicase_blog_breadcrumb',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Main color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#4e97fd',
				'settings' => 'medicase_main_color',
				'label' => esc_attr__( 'Main Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can customize the main color.', 'medicase-core' ),
				'section' => 'medicase_main_color_section',
			)
		);

		/*====== Second color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e4573d',
				'settings' => 'medicase_second_color',
				'label' => esc_attr__( 'Second Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can customize the second color.', 'medicase-core' ),
				'section' => 'medicase_main_color_section',
			)
		);
		
		/*====== Elementor Templates =======================================================*/
		/*====== Before Shop Elementor Templates ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_before_main_shop_elementor_template',
				'label'       => esc_html__( 'Before Shop Elementor Template', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
		
		/*====== After Shop Elementor Templates ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_after_main_shop_elementor_template',
				'label'       => esc_html__( 'After Shop Elementor Template', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
		
		/*====== Before Header Elementor Templates ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_before_main_header_elementor_template',
				'label'       => esc_html__( 'Before Header Elementor Template', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
	
		/*====== After Header Elementor Templates ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_after_main_header_elementor_template',
				'label'       => esc_html__( 'After Header Elementor Template', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
		
		/*====== Before Footer Elementor Template ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_before_main_footer_elementor_template',
				'label'       => esc_html__( 'Before Footer Elementor Template', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
		
		/*====== After Footer Elementor  Template ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'medicase_after_main_footer_elementor_template',
				'label'       => esc_html__( 'After Footer Elementor Templates', 'medicase' ),
				'section'     => 'medicase_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'medicase' ),
				'choices'     => medicase_get_elementorTemplates('section'),
			)
		);
		
		/*====== Templates Repeater For each category ======*/
		add_action( 'init', function() {
			medicase_customizer_add_field (
				array(
					'type' => 'repeater',
					'settings' => 'medicase_elementor_template_each_shop_category',
					'label' => esc_attr__( 'Template For Categories', 'medicase-core' ),
					'description' => esc_attr__( 'You can set template for each category.', 'medicase-core' ),
					'section' => 'medicase_elementor_templates_section',
					'fields' => array(
						
						'category_id' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Select Category', 'medicase-core' ),
							'description' => esc_html__( 'Set a category', 'medicase-core' ),
							'priority'    => 10,
							'default'     => '',
							'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'product_cat') )
						),
						
						'medicase_before_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Shop Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
							'default'     => '',
							'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'medicase-core' ),
						),
						
						'medicase_after_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Shop Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
						),
						
						'medicase_before_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Header Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
						),
						
						'medicase_after_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Header Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
						),
						
						'medicase_before_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Footer Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
						),
						
						'medicase_after_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Footer Elementor Template', 'medicase-core' ),
							'choices'     => medicase_get_elementorTemplates('section'),
						),
						

					),
				)
			);
		} );

		/*====== Map Settings ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_mapapi',
				'label' => esc_attr__( 'Google Map Api key', 'medicase-core' ),
				'description' => esc_attr__( 'Add your google map api key', 'medicase-core' ),
				'section' => 'medicase_map_settings_section',
				'default' => '',
			)
		);
		
	/*====== Header ======*/
		/*====== Header Panels ======*/
		Kirki::add_panel (
			'medicase_header_panel',
			array(
				'title' => esc_html__( 'Header Settings', 'medicase-core' ),
				'description' => esc_html__( 'You can customize the header from this panel.', 'medicase-core' ),
			)
		);

		$sections = array (
			'header_logo' => array(
				esc_attr__( 'Logo', 'medicase-core' ),
				esc_attr__( 'You can customize the logo which is on header..', 'medicase-core' )
			),
			
			'header_top' => array(
				esc_attr__( 'Header Top', 'medicase-core' ),
				esc_attr__( 'You can customize top header..', 'medicase-core' )
			),
		
			'header_general' => array(
				esc_attr__( 'Header General', 'medicase-core' ),
				esc_attr__( 'You can customize the header.', 'medicase-core' )
			),
			
			'header_sidebar_menu' => array(
				esc_attr__( 'Sidebar Menu', 'medicase-core' ),
				esc_attr__( 'You can customize the sidebar menu.', 'medicase-core' )
			),

			'header_color' => array(
				esc_attr__( 'Header Color', 'medicase-core' ),
				esc_attr__( 'You can customize the header color.', 'medicase-core' )
			),

			'header_preloader' => array(
				esc_attr__( 'Preloader', 'medicase-core' ),
				esc_attr__( 'You can customize the loader.', 'medicase-core' )
			),
			

		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'medicase_header_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'medicase_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Logo ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_logo',
				'label' => esc_attr__( 'Logo', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload a logo.', 'medicase-core' ),
				'section' => 'medicase_header_logo_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Logo Text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_logo_text',
				'label' => esc_attr__( 'Set Logo Text', 'medicase-core' ),
				'description' => esc_attr__( 'You can set logo as text.', 'medicase-core' ),
				'section' => 'medicase_header_logo_section',
				'default' => 'medicase',
			)
		);
		
		/*====== Logo Size ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'medicase_logo_size',
				'label'       => esc_html__( 'Logo Size', 'medicase' ),
				'description' => esc_attr__( 'You can set size of the logo.', 'medicase' ),
				'section'     => 'medicase_header_logo_section',
				'default'     => 195,
				'priority'    => 30,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.logo img',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		
		/*====== Top Header Text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'medicase_top_header_text',
				'label' => esc_attr__( 'Text', 'medicase-core' ),
				'description' => esc_attr__( 'You can set top header text', 'medicase-core' ),
				'section' => 'medicase_header_top_section',
				'default' => '',
			)
		);

		/*====== Top Header Box text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'medicase_top_header_box_text',
				'label' => esc_attr__( 'Icon', 'medicase-core' ),
				'description' => esc_attr__( 'You can set contact icon e.g: linearicons-phone-wave .', 'medicase-core' ),
				'section' => 'medicase_header_top_section',
				'default' => '+123 (456) 7879',
			)
		);
		
		/*====== Header Contact URL ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'medicase_header_contact_url',
				'label' => esc_attr__( 'URL', 'medicase-core' ),
				'description' => esc_attr__( 'Add an url.', 'medicase-core' ),
				'section' => 'medicase_header_contact_detail_section',
				'default' => 'tel:1234567689',
			)
		);
		
		/*====== Header Cart Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_header_cart',
				'label' => esc_attr__( 'Header Cart', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose status of the mini cart on the header.', 'medicase-core' ),
				'section' => 'medicase_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Search Button Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_header_search_button',
				'label' => esc_attr__( 'Header Search Button', 'medicase-core' ),
				'description' => esc_attr__( 'You can choose status of the search button on the header.', 'medicase-core' ),
				'section' => 'medicase_header_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Search on Header ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_header_mobile_search',
				'label' => esc_attr__( 'Mobile Search', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable mobile search on header.', 'medicase-core' ),
				'section' => 'medicase_header_general_section',
				'default' => '0',
			)
		);

		/*====== Top Header Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_top_header',
				'label' => esc_attr__( 'Top Header', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable the top header', 'medicase-core' ),
				'section' => 'medicase_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Sidebar Menu Widget ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_header_sidebar_menu',
				'label' => esc_attr__( 'Sidebar Widget', 'medicase-core' ),
				'description' => esc_attr__( 'You can add widgets from Dashboard > Appearance > Widgets > Menu Sidebar', 'medicase-core' ),
				'section' => 'medicase_header_sidebar_menu_section',
				'default' => '0',
			)
		);
		
		/*====== Sidebar Menu Logo ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_sidebar_menu_logo',
				'label' => esc_attr__( 'Logo', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload a logo.', 'medicase-core' ),
				'section' => 'medicase_header_sidebar_menu_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'medicase_header_sidebar_menu',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Sidebar Menu logo Size ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'medicase_sidebar_logo_size',
				'label'       => esc_html__( 'Sidebar Menu Logo Size', 'medicase' ),
				'description' => esc_attr__( 'You can set size of the logo.', 'medicase' ),
				'section'     => 'medicase_header_sidebar_menu_section',
				'default'     => 195,
				'priority'    => 30,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.extra-info .logo-side img',
					'property'    => 'width',
					'units' => 'px',
				], ],
				'required' => array(
					array(
					  'setting'  => 'medicase_header_sidebar_menu',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Top Header BG color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'medicase_top_header_bg',
				'label' => esc_attr__( 'Top Header Bg', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top header background.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);
		
		/*====== Top Header Style ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'medicase_top_header_font_typography',
				'label'       => esc_attr__( 'Top Header Featured Typography', 'medicase' ),
				'section'     => 'medicase_header_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.shop-menu ul li a',
					],
				],		
			)
		);
		
		/*====== Top Header Font color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_top_header_font_color',
				'label' => esc_attr__( 'Top Header Font Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top header font.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);
		
		/*====== Top Header Font Hover color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_top_header_font_hvrcolor',
				'label' => esc_attr__( 'Top Header Font Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top header font.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);

		/*====== Main Header BG color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'medicase_main_header_bg',
				'label' => esc_attr__( 'Main Header Bg', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom header background.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);
		
		/*====== Main Header Style ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'medicase_main_header_font_typography',
				'label'       => esc_attr__( 'Main Header Featured Typography', 'medicase' ),
				'section'     => 'medicase_header_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '16px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.main-menu ul li a ',
					],
				],		
			)
		);
		
		/*====== Main Header Font color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_main_header_font_color',
				'label' => esc_attr__( 'Main Header Font Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom header font.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);
		
		/*====== Main Header Font Hover color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#4e97fd',
				'settings' => 'medicase_main_header_font_hvrcolor',
				'label' => esc_attr__( 'Main Header Font Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom header font.', 'medicase-core' ),
				'section' => 'medicase_header_color_section',
			)
		);

		/*====== PreLoader Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_preloader',
				'label' => esc_attr__( 'Disable Loader', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable the loader.', 'medicase-core' ),
				'section' => 'medicase_header_preloader_section',
				'default' => '0',
			)
		);

		/*====== Loader Image ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'medicase_preloader_image',
				'label' => esc_attr__( 'Image', 'medicase-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'medicase-core' ),
				'section' => 'medicase_header_preloader_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'medicase_preloader',
					  'operator' => '==',
					  'value'    => '0',
					),
				),
			)
		);
		
	/*====== medicase Widgets ======*/
		/*====== Widgets Panels ======*/
		Kirki::add_panel (
			'medicase_widgets_panel',
			array(
				'title' => esc_html__( 'medicase Widgets', 'medicase-core' ),
				'description' => esc_html__( 'You can customize the medicase widgets.', 'medicase-core' ),
			)
		);

		$sections = array (
			
			'footer_about' => array(
				esc_attr__( 'Footer About', 'medicase-core' ),
				esc_attr__( 'You can customize the footer about widget.', 'medicase-core' )
			),

			'footer_contact' => array(
				esc_attr__( 'Footer Contact', 'medicase-core' ),
				esc_attr__( 'You can customize the footer contact widget.', 'medicase-core' )
			),
		
			'contact_box' => array(
				esc_attr__( 'Contact Box', 'medicase-core' ),
				esc_attr__( 'You can customize the contact box widget.', 'medicase-core' )
			),
			
			'social_list' => array(
				esc_attr__( 'Social List', 'medicase-core' ),
				esc_attr__( 'You can customize the social list widget.', 'medicase-core' )
			),
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'medicase_widgets_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'medicase_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		
		/*====== Footer About Widget Textarea ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'medicase_footer_about_text',
				'label' => esc_attr__( 'Content', 'medicase-core' ),
				'description' => esc_attr__( 'You can set text for the about widget.', 'medicase-core' ),
				'section' => 'medicase_footer_about_section',
				'default' => '',
			)
		);
		
		/*====== Footer About Widget Social======*/
		medicase_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'medicase_footer_about_social',
				'label' => esc_attr__( 'Footer About Social', 'medicase-core' ),
				'description' => esc_attr__( 'You can set the widget settings.', 'medicase-core' ),
				'section' => 'medicase_footer_about_section',
				'fields' => array(
					'social_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'medicase-core' ),
						'description' => esc_attr__( 'You can set an icon from fontawesome.com for example; "facebook-f"', 'medicase-core' ),
					),

					'social_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'medicase-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'medicase-core' ),
					),

				),
			)
		);

		/*====== Footer Contact Widget Repeater ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'medicase_footer_contact_widget',
				'label' => esc_attr__( 'Contact', 'medicase-core' ),
				'description' => esc_attr__( 'You can set contact details for medicase Contact Widget.', 'medicase-core' ),
				'section' => 'medicase_footer_contact_section',
				'fields' => array(
				
					'contact_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Contact Icon', 'medicase-core' ),
						'description' => esc_attr__( 'set an icon.', 'medicase-core' ),
					),

					'contact_info' => array(
						'type' => 'textarea',
						'label' => esc_attr__( 'Contact Info', 'medicase-core' ),
						'description' => esc_attr__( 'Add contact details.', 'medicase-core' ),
					),
					
					
				),
			)
		);
		
		
		
		/*====== Contact Box Widget ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'medicase_contact_box_widget',
				'label' => esc_attr__( 'Contact Box Widget', 'medicase-core' ),
				'description' => esc_attr__( 'You can set contact detail.', 'medicase-core' ),
				'section' => 'medicase_contact_box_section',
				'fields' => array(
					'contact_title' => array(
						'type' => 'textarea',
						'label' => esc_attr__( 'Title', 'medicase-core' ),
						'description' => esc_attr__( 'You can enter a text.', 'medicase-core' ),
					),

					'contact_subtitle' => array(
						'type' => 'textarea',
						'label' => esc_attr__( 'Subtitle', 'medicase-core' ),
						'description' => esc_attr__( 'You can enter a text.', 'medicase-core' ),
					),
				),
			)
		);
		
		/*====== Social List Widget ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'medicase_social_list_widget',
				'label' => esc_attr__( 'Social List Widget', 'medicase-core' ),
				'description' => esc_attr__( 'You can set social icons.', 'medicase-core' ),
				'section' => 'medicase_social_list_section',
				'fields' => array(
					'social_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'medicase-core' ),
						'description' => esc_attr__( 'You can set an icon from fontawesome.com for example; "facebook"', 'medicase-core' ),
					),

					'social_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'medicase-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'medicase-core' ),
					),

				),
			)
		);
		
	/*====== Footer ======*/
		/*====== Footer Panels ======*/
		Kirki::add_panel (
			'medicase_footer_panel',
			array(
				'title' => esc_html__( 'Footer Settings', 'medicase-core' ),
				'description' => esc_html__( 'You can customize the footer from this panel.', 'medicase-core' ),
			)
		);

		$sections = array (

			'top_footer' => array(
				esc_attr__( 'Top Footer', 'medicase-core' ),
				esc_attr__( 'You can customize the top footer settings.', 'medicase-core' )
			),
			
			'footer_general' => array(
				esc_attr__( 'Footer General', 'medicase-core' ),
				esc_attr__( 'You can customize the footer settings.', 'medicase-core' )
			),

			'footer_color' => array(
				esc_attr__( 'Footer Color', 'medicase-core' ),
				esc_attr__( 'You can customize the footer colors.', 'medicase-core' )
			),
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'medicase_footer_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'medicase_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}

		
		/*====== Top Header Text ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'medicase_top_footer_text',
				'label' => esc_attr__( 'Text', 'medicase-core' ),
				'description' => esc_attr__( 'You can add the instagram shortcode. for example: [instagram-feed]', 'medicase-core' ),
				'section' => 'medicase_top_footer_section',
				'default' => 'instagram-feed',
			)
		);
		
		/*====== Copyright ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'medicase_copyright',
				'label' => esc_attr__( 'Copyright', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a copyright text for the footer.', 'medicase-core' ),
				'section' => 'medicase_footer_general_section',
				'default' => '',
			)
		);

		/*====== Footer Menu Toggle ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'medicase_footer_menu',
				'label' => esc_attr__( 'Footer Menu', 'medicase-core' ),
				'description' => esc_attr__( 'Disable or Enable the footer menu.', 'medicase-core' ),
				'section' => 'medicase_footer_general_section',
				'default' => '0',
			)
		);

		/*====== Footer Column ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'radio-buttonset',
				'settings'    => 'medicase_footer_column',
				'description' => esc_attr__( 'You can set footer column.', 'medicase-core' ),
				'section'     => 'medicase_footer_general_section',
				'default'     => '4columns',
				'priority'    => 10,
				'choices'     => [
					'3columns'  => esc_html__( '3 columns', 'medicase' ),
					'4columns' 	=> esc_html__( '4 columns', 'medicase' ),
					'5columns'  => esc_html__( '5 columns', 'medicase' ),
				],
			)
		);

		/*====== Footer Column Padding Top  ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'medicase_footer_column_padding_top',
				'label'       => esc_html__( 'Footer Column Padding', 'medicase' ),
				'description' => esc_attr__( 'Padding-Top.', 'medicase' ),
				'section'     => 'medicase_footer_general_section',
				'default'     => 0,
				'choices'     => [
					'min'  => 0,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.footer-wrapper',
					'property'    => 'padding-top',
					'units' => 'px',
				], ],
				
			)
		);
		
		/*====== Footer Column Padding Bottom  ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'medicase_footer_column_padding_bottom',
				'section'     => 'medicase_footer_general_section',
				'description' => esc_attr__( 'Padding-Bottom.', 'medicase' ),
				'default'     => 0,
				'choices'     => [
					'min'  => 0,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.footer-wrapper',
					'property'    => 'padding-bottom',
					'units' => 'px',
				], ],
			)
		);

		/*====== Footer Top BG color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'medicase_footer_top_bg',
				'label' => esc_attr__( 'Footer Top Background', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top footer background.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Top Widget Title Style ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'medicase_footer_top_widget_title_typo',
				'label'       => esc_attr__( 'Footer Top Widget Title Featured Typography', 'medicase' ),
				'section'     => 'medicase_footer_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '20px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => 'h3.footer-title',
					],
				],		
			)
		);

		/*====== Footer Top Widget Title color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#333333',
				'settings' => 'medicase_footer_top_widget_title_color',
				'label' => esc_attr__( 'Footer Top Widget Title Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top footer widget title.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Top Widget Title Hover color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#333333',
				'settings' => 'medicase_footer_top_widget_title_hvrcolor',
				'label' => esc_attr__( 'Footer Top Widget Title Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top footer widget title.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Top Widget Text Style ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'medicase_footer_top_widget_text_typo',
				'label'       => esc_attr__( 'Footer Top Widget Text Featured Typography', 'medicase' ),
				'section'     => 'medicase_footer_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.footer-area p, .themefushionfooterwidget ul li a, .footer-icon a',
					],
				],		
			)
		);

		/*====== Footer Top Widget Text color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_footer_top_widget_text_color',
				'label' => esc_attr__( 'Footer Top Widget Text Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top footer widget text.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Top Widget Text Hover color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_footer_top_widget_text_hvrcolor',
				'label' => esc_attr__( 'Footer Top Widget Text Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for top footer widget text.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Bottom BG ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'medicase_footer_bottom_bg',
				'label' => esc_attr__( 'Footer Bottom Background', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom footer background.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Bottom Font Style ======*/
		medicase_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'medicase_footer_bottom_font_typo',
				'label'       => esc_attr__( 'Footer Bottom Font Featured Typography', 'medicase' ),
				'section'     => 'medicase_footer_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.footer-bottom-link ul li a, .copyright p',
					],
				],		
			)
		);

		/*====== Footer Bottom Font Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_footer_bottom_font_color',
				'label' => esc_attr__( 'Footer Bottom Font Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom footer font.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		
		/*====== Footer Bottom Font Hover Color ======*/
		medicase_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9b9b',
				'settings' => 'medicase_footer_bottom_font_hvrcolor',
				'label' => esc_attr__( 'Footer Bottom Font Hover Color', 'medicase-core' ),
				'description' => esc_attr__( 'You can set a color for bottom footer font.', 'medicase-core' ),
				'section' => 'medicase_footer_color_section',
			)
		);
		

