<?php
/*
 * Footer Options
 */

Redux::setSection( $options, array(
    'title' => esc_html__( 'Footer', 'medicase-core' ),
    'id'    => 'footer-editor',
    'icon'  => 'eicon-footer',
    'customizer_width' => '500px',
) );

Redux::setSection( $options, array(
    'title' => esc_html__('Footer Logo','medicase-core'),
    'id'    => 'footer-logo',

    'subsection' => true,
    'desc'  => esc_html__('This section contains options for footer.','medicase-core'),
    'fields'=> array(

      array(
            'id' => 'info_L6N7VDM05M',
            'type' => 'info',
            'style' => 'custom',
            'color' => sanitize_hex_color($color),
            'title' => __('This sectin contain options for Footer logo', 'medicase-core-core') ,
        ) ,

        array(
            'id' => 'indentL6N7VDM05M',
            'type' => 'section',
            'indent' => true
        ) ,

        array(
            'id'       => 'logo_footer',
            'type'     => 'media',
            'url'      => false,
            'title'    => esc_html__( 'Footer Logo','medicase-core'),
            'default'  => array(
            'url'=>'http://s.wordpress.org/style/images/codeispoetry.png'
            ),

        ),

    )
));



Redux::setSection( $options, array(
    'title' => esc_html__('Footer Option','medicase-core'),
    'id'    => 'footer-section',

    'subsection' => true,
    'fields'=> array(

        array(
            'id' => 'info_N7VDM05M',
            'type' => 'info',
            'style' => 'custom',
            'color' => sanitize_hex_color($color),
            'title' => __('This section contains options for footer', 'medicase-core') ,
        ) ,

        array(
            'id' => 'indent_N7VDM05M',
            'type' => 'section',
            'indent' => true
        ) ,



        array(
            'id'        => 'footer_layout',
            'type'      => 'select',
            'title'     => esc_html__( 'Footer Layout Type','medicase-core' ),
            'subtitle'  => wp_kses( __( '<br />Choose among these structures (1column, 2column and 3column) for your footer section.<br />To filling these column sections you should go to appearance > widget.<br />And put every widget that you want in these sections.','medicase-core' ), array( 'br' => array() ) ),
            'options'   => array(
                                '1' =>  esc_html__( 'Footer Layout 1','medicase-core' ),
                                '2' =>  esc_html__( 'Footer Layout 2','medicase-core' ),
                                '3' =>  esc_html__( 'Footer Layout 3','medicase-core' ),
                                '4' =>  esc_html__( 'Footer Layout 4','medicase-core' ),
                            ),
            'default'   => '4',
        ),
         array(
            'id' => 'footer_back_opt_switch',
            'type' => 'button_set',
            'title' => esc_html__('Background', 'medicase-core') ,

            'options' => array(
                'none' => esc_html__('none', 'medicase-core') ,
                'image' => esc_html__('Image', 'medicase-core') ,
                'color' => esc_html__('Color', 'medicase-core'),
            ) ,
            'default' => esc_html__('none', 'medicase-core')
        ) ,
         array(
            'id' => 'footer_back_img',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Image', 'medicase-core') ,
            'read-only' => false,
            'required' => array(
                'footer_back_opt_switch',
                '=',
                'image'
            ) ,
        ) ,

        array(
            'id' => 'footer_back_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'medicase-core') ,

            'mode' => 'background',
            'required' => array(
                'footer_back_opt_switch',
                '=',
                'color'
            ) ,
            'transparent' => false
        ) ,
    )
));

Redux::setSection( $options, array(
    'title'      => esc_html__( 'Footer Copyright', 'medicase-core' ),
    'id'         => 'footer-copyright',

    'subsection' => true,
    'fields'     => array(
        array(
            'id' => 'info_7VDM05M',
            'type' => 'info',
            'style' => 'custom',
            'color' => sanitize_hex_color($color),
            'title' => __('This section contains options Footer Copyright', 'medicase-core') ,
        ) ,

        array(
            'id' => 'indent_7VDM05M',
            'type' => 'section',
            'indent' => true
        ) ,
        array(
            'id'        => 'copyright_text',
            'type'      => 'textarea',
            'title'     => esc_html__( 'Copyright Text','medicase-core'),
            'default'   => esc_html__( 'Copyright '.date('Y').' medicase All Rights Reserved','medicase-core'),
        ),

        // array(
        //     'id'        => 'medicase_reserved_text',
        //     'type'      => 'textarea',
        //     'title'     => esc_html__( 'Right Reserved Text','medicase-core'),
        //     'default'   => esc_html__( 'All Rights Reserved','medicase-core'),
        // ),


    ))
);

Redux::setSection( $options, array(
    'title'      => esc_html__( 'Subscribe', 'medicase-core' ),
    'id'         => 'medicase-subscribe',
    
    'subsection' => true,
    'fields'     => array(

        array(
            'id' => 'info_7VM05M',
            'type' => 'info',
            'style' => 'custom',
            'color' => sanitize_hex_color($color),
            'title' => __('This section contains options Subscription Block', 'medicase-core') ,
        ) ,

        array(
            'id' => 'indent_7VM05M',
            'type' => 'section',
            'indent' => true
        ) ,

        array(
            'id'        => 'footer_subscribe',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Subscribe','medicase-core'),
            'subtitle' => esc_html__( 'Display Subscribe On All page', 'medicase-core' ),
            'options'   => array(
                            'yes' => esc_html__('Yes','medicase-core'),
                            'no' => esc_html__('No','medicase-core')
                        ),
            'default'   => esc_html__('yes','medicase-core')
        ),

          array(
            'id' => 'subscribe_img',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Subscription Image', 'medicase-core') ,
            'read-only' => false,                        
            'required'  => array( 'footer_subscribe', '=', 'yes' ),
        ) ,

        array(
            'id'        => 'subscribe_title',
            'type'      => 'text',
            'title'     => esc_html__( 'Subscribe Title','medicase-core'),
            'required'  => array( 'footer_subscribe', '=', 'yes' ),
            
        ),

        // array(
        //     'id'        => 'medicase_sub_description',
        //     'type'      => 'textarea',
        //     'title'     => esc_html__( 'Subscribe Description','medicase-core'),
        //     'required'  => array( 'footer_subscribe', '=', 'yes' ),
            
        // ),

        array(
            'id'        => 'subscribe_shortcode',
            'type'      => 'text',
            'title'     => esc_html__( 'Subscribe Shortcode','medicase-core'),
            'subtitle'  => wp_kses( __( '<br />Put you Mailchimp for WP Shortcode here','medicase-core' ), array( 'br' => array() ) ),
            'required'  => array( 'footer_subscribe', '=', 'yes' ),
        ),
    )) 
);