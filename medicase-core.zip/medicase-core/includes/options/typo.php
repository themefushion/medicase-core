<?php
/*
 * Color Options
 */
Redux::setSection( $options, array(
    'title' => esc_html__('Typography','medicase-core'),
    'id'    => 'typo-section',
    'icon'       => 'el el-font',     

    'fields'=> array(

        array(
            'id' => 'info_N7VD051',
            'type' => 'info',
            'style' => 'custom',
            'color' => sanitize_hex_color($color),
            'title' => __('This section contains options Typography', 'medicase-core') ,
        ) ,

        array(
            'id' => 'indent_N7VDM0M1',
            'type' => 'section',
            'indent' => true
        ) ,  
        array(
            'id'        => 'pt_custom_typo',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Use Custom Typography','medicase-core'),
            
            'options'   => array(
                            'yes' => esc_html__('Yes','medicase-core'),
                            'no' => esc_html__('No','medicase-core')
                        ),
            'default'   => esc_html__('no','medicase-core')
        ),      
        array(
            'id'          => 'h1_typo',
            'type'        => 'typography', 
            'title'       => __('H1', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'h2_typo',
            'type'        => 'typography', 
            'title'       => __('H2', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'h3_typo',
            'type'        => 'typography', 
            'title'       => __('H3', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'h4_typo',
            'type'        => 'typography', 
            'title'       => __('H4', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'h5_typo',
            'type'        => 'typography', 
            'title'       => __('H5', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'h6_typo',
            'type'        => 'typography', 
            'title'       => __('H6', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
        array(
            'id'          => 'body_typo',
            'type'        => 'typography', 
            'title'       => __('Body', 'medicase-core'),
            'google'      => true, 
            'font-backup' => false,
            'font-size' => true,
            'line-height' => false,
            'font-style' => false,
            'font-weight' => false,
            'subset' => false,
            'text-align' => false,
            'text-transform' => true,
            'color' => false,        
            'units'       =>'px',        
            'default'     => array(
                ),
            'required' => array(
                'pt_custom_typo',
                '=',
                'yes'
            ) ,
        ),
    )
));