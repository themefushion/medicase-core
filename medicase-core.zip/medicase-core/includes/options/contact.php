<?php
/*
 * Footer Options
 */
Redux::setSection( $options, array(
    'title'      => esc_html__( 'Contact', 'medicase-core' ),
    'id'         => 'contact_section',
    'icon'       => 'el el-address-book',
    'fields'     => array(

        array(
            'id'        => 'phone',
            'type'      => 'text',
            'title'     => esc_html__( 'Contact Number','medicase-core'),


        ),
         array(
            'id'        => 'email',
            'type'      => 'text',
            'title'     => esc_html__( 'First Email','medicase-core'),


        ),

         array(
            'id'        => 'email1',
            'type'      => 'text',
            'title'     => esc_html__( 'Second Email','medicase-core'),


        ),
        array(
            'id'        => 'address',
            'type'      => 'textarea',
            'title'     => esc_html__( 'Address','medicase-core'),
            

        ),
        array(
            'id'        => 'time',
            'type'      => 'text',
            'title'     => esc_html__( 'Time Text','medicase-core'),


        ),
        array(
            'id'        => 'text',
            'type'      => 'textarea',
            'title'     => esc_html__( 'Text','medicase-core'),
            

        ),

    )
));