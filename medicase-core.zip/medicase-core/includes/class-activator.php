<?php

/**
 * Fired during plugin activation
 *
 * @link       https://themeforest.net/user/themefushion
 * @since      1.0.0
 *
 * @package    medicase
 * @subpackage medicase/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    medicase
 * @subpackage medicase/includes
 * @author     author-medicase <author-medicase@gmail.com>
 */
class Medic_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
