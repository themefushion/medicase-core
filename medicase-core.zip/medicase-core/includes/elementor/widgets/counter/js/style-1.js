
if (jQuery('.timer').length > 0 ) {
  jQuery(this).countTo();
}