<?php
namespace Elementor;
use medicase\Elementor_widgets\Medic_Elementor_Init as SCEW;
if ( ! defined( 'ABSPATH' ) ) exit;

class Infobox extends Widget_Base {

	public function get_name() {
		return __( 'infobox', 'medicase' );
	}

	public function get_title() {
		return __( 'Infobox', 'medicase' );
	}

	public function get_categories() {
		return [ SCEW::get_category() ];
    }

	/**
	 * Get widget icon.
	 *
	 * Retrieve heading widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-box';
	}
     
     
	// public function __construct( $data = array(), $args = null ) {
	// 	parent::__construct( $data, $args );
	// 	wp_register_style( 'infobox-style-1-css', plugin_dir_url( __FILE__ )  . '/css/style-1.css', array(), '1.0.0' );
	// 	wp_register_style( 'infobox-style-2-css', plugin_dir_url( __FILE__ )  . '/css/style-2.css', array(), '1.0.0' );
	// 	 wp_register_style( 'infobox-style-3-css', plugin_dir_url( __FILE__ )  . '/css/style-3.css', array(), '1.0.0' );	
	// }
	// public function get_style_depends() {
	// 	return ['infobox-style-1-css','infobox-style-2-css','infobox-style-3-css'];
	// }
	   

	protected function register_controls() {
		$this->start_controls_section(
			'sectioninfobox',
			[
				'label' => __( 'Style', 'medicase' ),
			]
		);
		$this->add_control(
			'infobox_style',
			[
				'label' => __( 'Infobox Style', 'medicase' ),
				'type' => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => __( 'Style 1', 'medicase' ),
					'2'  => __( 'Style 2', 'medicase' ),
					'3'  => __( 'Style 3', 'medicase' ),
				],
			]
		);


        $this->end_controls_section();

		$this->start_controls_section(
			'sectionftf',
			[
				'label' => __( 'Infobox', 'medicase' ),
			]
		);



        $this->add_control(
			'image_style',
			[
				'label'      => __( 'Choose Image/Icon', 'medicase' ),
				'type'       => Controls_Manager::SELECT,
				'default'    => 'none',
				'options'    => [
					'none'       => __( 'None', 'medicase' ),
					'1'          => __( 'Image', 'medicase' ),
					'2'          => __( 'Icon', 'medicase' ),

				],
			]
		);
		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'medicase'),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],

				'condition' => [
					'image_style' => '1',
				],
			]
		);
		$this->add_control(
			'selected_icon',
			[
				'label' => __( 'Choose Icon', 'medicase' ),
				'type' => Controls_Manager::ICONS,
				'label_block' => true,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
                'fa4compatibility' => 'icon',
				'separator' => 'before',
				'condition' => [
					'image_style' => '2',
				]
			]
		);

		$this->add_control(
			'single_icon',
			[
				'label' => __( 'Single Icon', 'medicase' ),
				'type' => Controls_Manager::ICONS,
				'label_block' => true,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
                'fa4compatibility' => 'icon',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' => __( 'Title', 'medicase' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is sample title', 'medicase' ),
				'placeholder' => __( 'Enter your title', 'medicase' ),
				'label_block' => true,
			]
        );

        $this->add_control(
			'title_tag',
			[
				'label' => __( 'Title Tag', 'medicase' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'h5',
				'options' => [
					'h1'  => 'h1',
					'h2'  => 'h2',
					'h3'  => 'h3',
					'h4'  => 'h4',
					'h5'  => 'h5',
					'h6'  => 'h6',
					'p'  => 'p',
					'span'  => 'span',

				],

			]

		);

		$this->add_control(
			'desc_content',
			[
				'label' => __( 'Enable/disable description', 'medicase' ),
				'type' => Controls_Manager::SWITCHER ,
				'label_on' => __( 'Show', 'medicase' ),
				'label_off' => __( 'Hide', 'medicase' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);

		$this->add_control(
			'description_text',
			[
				'label' => __( 'Content', 'medicase' ),
				'type' => Controls_Manager::WYSIWYG,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Enter your Description here', 'medicase' ),
				'placeholder' => __( 'Enter your description', 'medicase' ),
				'separator' => 'before',
				'rows' => 10,
				'show_label' => true,
				'condition' => [
					'desc_content' => 'yes',
				]
			]
		);


        $this->add_control(
			'title_number',
			[
				'label' => __( 'Number', 'medicase' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is number', 'medicase' ),
				'placeholder' => __( 'Enter your number', 'medicase' ),
				'label_block' => true,
				'condition' => [
					'infobox_style' => ['1'],
				]
			]
        );

        $this->add_control(
			'number_icon',
			[
				'label' => __( 'Number Icon', 'medicase' ),
				'type' => Controls_Manager::ICONS,
				'label_block' => true,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
                'fa4compatibility' => 'icon',
				'separator' => 'before',
				'condition' => [
					'infobox_style' => ['1'],
				]
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'enable_disable',
			[
				'label' => __( 'Enable/disable', 'medicase' ),
				'type' => Controls_Manager::SWITCHER ,
				'label_on' => __( 'Show', 'medicase' ),
				'label_off' => __( 'Hide', 'medicase' ),
				'return_value' => 'yes',
				'default' => 'yes',

			]
		);

		$repeater->add_control(
			'tab_title',
			[
				'label' => __( 'Weakend Title', 'medicase' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is weakend title', 'medicase' ),
				'placeholder' => __( 'Enter your weakend title', 'medicase' ),
				'label_block' => true,

			]
        );


         $repeater->add_control(
			'tab_time',
			[
				'label' => __( 'Weakend Time', 'medicase' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is weakend title', 'medicase' ),
				'placeholder' => __( 'Enter your weakend title', 'medicase' ),
				'label_block' => true,

			]
        );

		$this->add_control(
			'tabs',
			[
				'label' => __( 'List Items', 'medicase' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'tab_title' => __( 'Monday', 'medicase' ),
					]

				],
				'title_field' => '{{{ tab_title }}}',
				'condition' => [
					'infobox_style' => ['3'],
				]
			]
		);

		$this->add_control(
			'show_button',
			[
				'label' => __( 'Show/Hide button', 'medicase' ),
				'type' => Controls_Manager::SWITCHER,
				'yes' => __( 'yes', 'medicase' ),
				'no' => __( 'no', 'medicase' ),
				'condition' => [
					'infobox_style' => ['2'],
				]

			]
        );

        $this->end_controls_section();



        $this->start_controls_section(
			'section__2p08cZ',
			[
				'label' => __( 'Alignment', 'medicase' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		 $this->add_responsive_control(
			'content_align',
			[
				'label' => __( 'Alignment', 'medicase' ),
				'type' => Controls_Manager::CHOOSE,
				'default'    => 'left',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'medicase' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'medicase' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'medicase' ),
						'icon' => 'eicon-text-align-right',
					]
		 		],
		 		'selectors' => [
					'{{WRAPPER}} .pt-info-box' => 'text-align: {{VALUE}};',
				]
			]
        );
		$this->end_controls_section();

		$this->start_controls_section(
			'section__2108cy',
			[
				'label' => __( 'Content', 'medicase' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'head_title',
			[
				'label' => __( 'Title', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		 $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'medicase' ),
				'selector' => '{{WRAPPER}} .pt-info-box .pt-info-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'medicase' ),

				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-title' => 'color: {{VALUE}};',
		 		],


			]
		);

		$this->add_control(
			'head_num',
			[
				'label' => __( 'Number', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',

			]
		);

		 $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'number_typography',
				'label' => __( 'Typography', 'medicase' ),
				'selector' => '{{WRAPPER}} .pt-info-box .pt-info-call h5',
			]
		);

		$this->add_control(
			'number_color',
			[
				'label' => __( 'Color', 'medicase' ),

				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-call h5' => 'color: {{VALUE}};',
		 		],


			]
		);

		$this->add_control(
			'head_desc',
			[
				'label' => __( 'Description', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		 $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => __( 'Typography', 'medicase' ),
				'selector' => '{{WRAPPER}} .pt-info-box .pt-infobox-description',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Color', 'medicase' ),

				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-infobox-description' => 'color: {{VALUE}};',

		 		],


			]
		);

		$this->add_control(
			'head_tab_title',
			[
				'label' => __( 'Weakend Title', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		 $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'weakend_typography',
				'label' => __( 'Typography', 'medicase' ),
				'selector' => '{{WRAPPER}} .pt-info-box .pt-info-hours .pt-info-hours-row ul li .pt-info-hours-title',
			]
		);

		$this->add_control(
			'weak_color',
			[
				'label' => __( 'Color', 'medicase' ),

				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-hours .pt-info-hours-row ul li .pt-info-hours-title' => 'color: {{VALUE}};',

		 		],


			]
		);


		$this->add_control(
			'head_tab_time',
			[
				'label' => __( 'Weakend Time', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		 $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'weaktime_typography',
				'label' => __( 'Typography', 'medicase' ),
				'selector' => '{{WRAPPER}} .pt-info-box .pt-info-hours .pt-info-hours-row ul li .pt-info-hours-content',
			]
		);

		$this->add_control(
			'weaktime_color',
			[
				'label' => __( 'Color', 'medicase' ),

				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-hours .pt-info-hours-row ul li .pt-info-hours-content' => 'color: {{VALUE}};',

		 		],


			]
		);

		 $this->end_controls_section();

		  $this->start_controls_section(
			'section__2456Z1',
			[
				'label' => __( 'Icon', 'medicase' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		 $this->add_control(
			'head_icon',
			[
				'label' => __( 'Right Icon', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		  $this->add_control(
			'icon_size_512832y67',
			[
				'label' => __( 'Typography', 'medicase' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],

				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],

				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-box-right-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
					'icon_color',
					[
						'label' => __( 'Color', 'medicase' ),

						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .pt-info-box .pt-info-box-right-icon i' => 'color: {{VALUE}};',
				 		],


					]
				);


		$this->add_control(
			'headss_icon',
			[
				'label' => __( 'Left Icon', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		  $this->add_control(
			'iconss_size_512832y67',
			[
				'label' => __( 'Typography', 'medicase' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],

				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],

				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-box-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
					'iconss_color',
					[
						'label' => __( 'Color', 'medicase' ),

						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .pt-info-box .pt-info-box-icon i' => 'color: {{VALUE}};',
				 		],


					]
				);


		$this->add_control(
			'headss_iconss',
			[
				'label' => __( 'Icon', 'medicase' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		  $this->add_control(
			'iconss_ssize_512832y67',
			[
				'label' => __( 'Typography', 'medicase' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],

				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],

				'selectors' => [
					'{{WRAPPER}} .pt-info-box .pt-info-call i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
					'iconsss_color',
					[
						'label' => __( 'Color', 'medicase' ),

						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .pt-info-box .pt-info-call i' => 'color: {{VALUE}};',
				 		],


					]
				);


		     $this->add_control(
					'icon_bbg_color',
					[
						'label' => __( 'Background Color', 'medicase' ),

						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .pt-info-box .pt-info-call i' => 'background-color: {{VALUE}};',
				 		],


					]
				);
		 $this->end_controls_section();

	// Add Button
		$this->start_controls_section(
			'section_Jnza436755QH5b77yuyo',
			[
				'label' => __( 'Button', 'medicase' ),
				'condition' => [
					'infobox_style' => ['2'],
				]
			]
		);
		$btn = new Button_Controls();
		$btn->get_btn_controls($this);


	 // Button End
	}

	protected function render() {
		$settings = $this->get_settings();
       if($settings['infobox_style'] == '1')
		{
			require plugin_dir_path( __FILE__ ) . 'style-1.php';
		}

		if($settings['infobox_style'] == '2')
		{
			require plugin_dir_path( __FILE__ ) . 'style-2.php';
		}
		if($settings['infobox_style'] == '3')
		{
			require plugin_dir_path( __FILE__ ) . 'style-3.php';
		}
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Infobox() );